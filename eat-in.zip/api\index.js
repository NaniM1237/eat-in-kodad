const app = require('../server.js');

module.exports = (req, res) => {
  // If Vercel rewrote the path to /api/index.js, restore the original incoming path
  const matched = req.headers['x-matched-path'] || req.headers['x-vercel-matched-path'] || req.headers['x-now-route-matches'];
  if (matched && matched !== '/api/index.js') {
    req.url = matched;
  }
  return app(req, res);
};
